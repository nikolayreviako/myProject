<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title></title>
		<link rel="stylesheet" href="scripts/jqui/jquery-ui.min.css">
		<link rel="stylesheet" href="style.css">
		<script src = 'scripts/jquery-3.3.1.js'></script>
		<script src = 'scripts/jqui/jquery-ui.min.js'></script>
		<script src = 'scripts/classes/WidthShower.js'></script>
		<!--- React --->
		<script src="https://unpkg.com/react@16/umd/react.development.js"></script>
		<script src="https://unpkg.com/react-dom@16/umd/react-dom.development.js"></script>
		<script src="https://unpkg.com/babel-standalone@6.15.0/babel.min.js"></script>			
		<!--- React end --->		
		<script type = 'text/babel' src = 'scripts/classes/DataForm.js'></script>
		<script type = 'text/babel' src = 'scripts/classes/TestClass.js'></script>
	<!--	<script type = 'text/babel' src = 'scripts/classes/TestClass.js'></script>-->
	<!--	<script type = 'text/babel' src = 'scripts/classes/WidthSetter.js'></script>-->
		<script type="text/javascript">		
			jQuery(document).ready(function(){
				var blockQuery = '.wrapper > div:first-of-type';
				var blockWidhShower = new WidthShower(blockQuery);
			/*	widthSetterObj = new WidthSetter(
					document.body,
					document.querySelectorAll('.wrapper > div:first-of-type')[0]
				);*/
				var widthSetterObj = new TestClass();				
				
			});
		</script>
	</head>	
	<body>
	<?php
	//	include_once('includes/ConnectionToDB.php');
	?>
		<div class = 'wrapper'>
			<div></div>
			<div></div>			
		</div>
	</body>
	
</html>







	
	