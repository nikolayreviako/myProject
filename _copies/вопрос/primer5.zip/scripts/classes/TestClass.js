class TestClass{
	constructor(){
		console.log('hello!');
	}
}