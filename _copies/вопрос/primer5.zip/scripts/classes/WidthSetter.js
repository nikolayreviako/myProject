class WidthSetter{
	constructor(parentEl,el){
		if (parentEl && el){
			this.parentEl = parentEl;
			this.el = el;
			this.addDataForm();
		}
	}
	addDataForm(){
	/*	ReactDOM.render(
			<DataForm />,
			el
		);*/
	}	
}