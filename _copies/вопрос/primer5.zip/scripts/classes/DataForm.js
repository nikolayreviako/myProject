class DataForm extends React.Component{
	constructor(attributes){
		super(attributes);
	}
	render(){
		return (
			<div>
				<form>
					
				</form>
				<p>Привет!</p>				
			</div>
		);
	}	
}