<?php
	class Configuration{
		public static $host = 'localhost';
		public static $userName = 'root';
		public static $password = '';
		public static $DBName = 'test_primer5';
	}
?>