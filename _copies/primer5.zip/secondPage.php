<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title></title>
		<link rel="stylesheet" href="scripts/jqui/jquery-ui.min.css">
		<link rel="stylesheet" href="styles/style.css">
		<script src = 'scripts/jquery-2.2.4.js'></script>
		<script src = 'scripts/jqui/jquery-ui.min.js'></script>
		<script type="text/javascript">			

		</script>
	</head>	
	<body>
	<h1>Страничка Б</h1>
	<?php
		include_once('includes/commonTest.php');
	?>
	</body>
</html>







	
	