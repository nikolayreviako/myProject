<ul>
	<li>
		<a href = 'index.php'>Главня страничка</a>
	</li>
	<li>
		<a href = 'secondPage.php'>Главня страничка</a>
	</li>	
</ul>
<?php
	echo '<p>'.$_SERVER['REQUEST_URI'].'</p>';
?>





	
	